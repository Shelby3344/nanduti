/* ================================================================
   HIPÓTLE — Jogo de Hipóteses Diagnósticas
   Lógica principal do jogo
   ================================================================ */

(function () {
  'use strict';

  // ── Constantes ──
  const MAX_TENTATIVAS = 5;
  const PONTOS_POR_TENTATIVA = { 1: 100, 2: 80, 3: 60, 4: 40, 5: 20 };
  const STORAGE_KEY = 'hipotle_v1';
  const TREINO_KEY = 'hipotle_treino_v1';
  const TIMEZONE = 'America/Sao_Paulo';

  // ── Estado ──
  let storage = loadStorage();
  let currentView = 'home';

  // Estado do jogo diário
  let dailyState = null;

  // Estado do treino
  let treinoState = null;
  let treinoEspecialidade = null;
  let treinoCasos = [];   // casos da especialidade aberta, na ordem do acervo
  let treinoIndice = 0;   // qual deles está em jogo
  let treinoPagina = 0;   // página da paginação numérica

  // ── Utilidades ──

  function getTodayKey() {
    return new Date().toLocaleDateString('en-CA', { timeZone: TIMEZONE });
  }

  function getDayNumber() {
    const start = new Date('2026-01-01');
    const today = new Date(getTodayKey());
    return Math.floor((today - start) / 86400000) + 1;
  }

  // No site os dois acervos são separados: o arquivo diário (casos que já foram
  // "caso do dia", com número #n) e o banco do Modo Treino. Mantemos a separação.
  const CASOS_ARQUIVO = CASES.filter(c => c.n !== undefined).sort((a, b) => a.n - b.n);
  const CASOS_TREINO = CASES.filter(c => c.n === undefined);

  function getDailyCaseIndex() {
    const dayNum = getDayNumber();
    return ((dayNum - 1) % CASOS_ARQUIVO.length);
  }

  function calcularPontos(tentativas, acertou) {
    if (!acertou) return 0;
    return PONTOS_POR_TENTATIVA[tentativas] || 0;
  }

  function normalizar(str) {
    return str.toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9\s]/g, '')
      .trim();
  }

  // Palavras sem valor diagnóstico: compartilhar só uma delas não deixa o palpite
  // "perto" da resposta. Verificado no site: "Doença de Chagas" contra uma resposta
  // com "de" dá vermelho, não amarelo.
  const ICONE_RESULTADO = { correct: '✅', partial: '🟡', wrong: '❌' };

  const PALAVRAS_VAZIAS = new Set([
    'de', 'da', 'do', 'das', 'dos', 'e', 'em', 'a', 'o', 'as', 'os', 'com', 'sem',
    'por', 'para', 'na', 'no', 'nas', 'nos', 'ao', 'aos', 'um', 'uma'
  ]);

  function palavrasSignificativas(texto) {
    return new Set(
      normalizar(texto).split(/\s+/).filter(p => p.length > 2 && !PALAVRAS_VAZIAS.has(p))
    );
  }

  // Três estados, como no site: 'correct', 'partial' (palavra inteira em comum
  // com alguma das respostas aceitas) e 'wrong'. Prefixo não conta — "Cardiomiopatia
  // periparto" contra "insuficiência cardíaca..." dá vermelho.
  function avaliarPalpite(palpite, questao) {
    const palpiteN = normalizar(palpite);
    if (questao.diagnosticosAceitos.some(d => normalizar(d) === palpiteN)) return 'correct';

    const doPalpite = palavrasSignificativas(palpite);
    const temSobreposicao = questao.diagnosticosAceitos.some(d => {
      for (const p of palavrasSignificativas(d)) if (doPalpite.has(p)) return true;
      return false;
    });
    return temSobreposicao ? 'partial' : 'wrong';
  }

  // ── Storage ──

  function loadStorage() {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) return JSON.parse(data);
    } catch (e) { /* ignore */ }
    return createFreshStorage();
  }

  function createFreshStorage() {
    return {
      streak: 0,
      maxStreak: 0,
      totalPlayed: 0,
      totalWon: 0,
      totalPontos: 0,
      melhorPontuacao: 0,
      historico: [],
      distribuicao: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, X: 0 },
      treinoCompletos: 0
    };
  }

  function saveStorage() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(storage));
  }

  function loadTreinoProgress() {
    try {
      const data = localStorage.getItem(TREINO_KEY);
      return data ? JSON.parse(data) : {};
    } catch (e) { return {}; }
  }

  function saveTreinoProgress(progress) {
    localStorage.setItem(TREINO_KEY, JSON.stringify(progress));
  }

  function registrarPartida(questaoId, status, numTentativas, tentativas, resultados) {
    const hoje = getTodayKey();
    const pontos = calcularPontos(numTentativas, status === 'won');
    const novaPartida = {
      date: hoje,
      questionId: questaoId,
      status: status,
      tentativas: numTentativas,
      pontos: pontos,
      palpites: tentativas,
      resultados: resultados
    };

    storage.historico = storage.historico.filter(h => h.date !== hoje);
    storage.historico.push(novaPartida);
    storage.totalPlayed++;
    if (status === 'won') {
      storage.totalWon++;
      storage.streak++;
    } else {
      storage.streak = 0;
    }
    storage.maxStreak = Math.max(storage.streak, storage.maxStreak);
    storage.totalPontos += pontos;
    storage.melhorPontuacao = Math.max(storage.melhorPontuacao, pontos);

    // Distribuição
    if (!storage.distribuicao) storage.distribuicao = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, X: 0 };
    if (status === 'won') {
      storage.distribuicao[numTentativas] = (storage.distribuicao[numTentativas] || 0) + 1;
    } else {
      storage.distribuicao['X'] = (storage.distribuicao['X'] || 0) + 1;
    }

    saveStorage();
  }

  // ── Navegação ──

  function navigateTo(view) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('view--active'));
    document.querySelectorAll('.sidebar__nav-item').forEach(n => n.classList.remove('sidebar__nav-item--active'));

    const viewEl = document.getElementById('view' + capitalize(view));
    if (viewEl) viewEl.classList.add('view--active');

    const navEl = document.querySelector(`[data-nav="${view}"]`);
    if (navEl) {
      document.querySelectorAll(`[data-nav="${view}"]`).forEach(n => n.classList.add('sidebar__nav-item--active'));
    }

    currentView = view;
    closeMenu();

    // Inicializar views
    if (view === 'home') initDaily();
    if (view === 'treino') initTreino();
    if (view === 'arquivo') renderArquivo();
    if (view === 'stats') renderStats();
  }

  function capitalize(str) {
    if (str === 'home') return 'Home';
    if (str === 'treino') return 'Treino';
    if (str === 'arquivo') return 'Arquivo';
    if (str === 'stats') return 'Stats';
    if (str === 'sobre') return 'Sobre';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  // ── Menu mobile ──

  function openMenu() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('menuOverlay');
    sidebar.classList.add('sidebar--open');
    overlay.hidden = false;
  }

  function closeMenu() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('menuOverlay');
    sidebar.classList.remove('sidebar--open');
    overlay.hidden = true;
  }

  // ── Atualizar sidebar stats ──

  function updateSidebarStats() {
    const jogados = storage.totalPlayed;
    const acertos = jogados > 0 ? Math.round((storage.totalWon / jogados) * 100) : 0;
    const pontos = storage.totalPontos;
    const streak = storage.streak;

    document.getElementById('statJogados').textContent = jogados;
    document.getElementById('statAcertos').textContent = acertos + '%';
    document.getElementById('statPontos').textContent = pontos;

    const streakEl = document.getElementById('sidebarStreak');
    const streakNum = document.getElementById('sidebarStreakNum');
    if (streak > 0) {
      streakEl.hidden = false;
      streakNum.textContent = streak;
    } else {
      streakEl.hidden = true;
    }
  }

  // ── JOGO DO DIA ──

  function initDaily() {
    const caseIndex = getDailyCaseIndex();
    const questao = CASOS_ARQUIVO[caseIndex];
    const dayNum = getDayNumber();
    const hoje = getTodayKey();

    document.getElementById('gameNumber').textContent = '#' + dayNum;

    // Verificar se já jogou hoje
    const historico = storage.historico.find(h => h.date === hoje && h.questionId === questao.id);

    if (historico) {
      // Já jogou: restaurar estado completo
      dailyState = {
        questao: questao,
        tentativas: historico.palpites || [],
        resultados: historico.resultados || [],
        status: historico.status,
        pistasReveladas: historico.status === 'won' ? historico.tentativas : 5
      };
    } else {
      // Novo jogo
      dailyState = {
        questao: questao,
        tentativas: [],
        resultados: [],
        status: 'playing',
        pistasReveladas: 1
      };
    }

    renderDaily();
  }

  function escaparHTML(texto) {
    return String(texto).replace(/[&<>"']/g, c => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }

  // Uma revelação é texto ou uma imagem ({ tipo: 'imagem', url, legenda }) — no acervo
  // alguns casos entregam um ECG no lugar da descrição.
  function revelacaoHTML(rev) {
    if (rev && typeof rev === 'object' && rev.tipo === 'imagem') {
      const legenda = rev.legenda
        ? `<span class="revelacao__legenda">${escaparHTML(rev.legenda)}</span>`
        : '';
      // Sem loading="lazy": a pista nasce em container oculto e a imagem nunca chegaria a carregar.
      return `${legenda}<img class="revelacao__img" src="${escaparHTML(rev.url)}" alt="Imagem do caso clínico">`;
    }
    return escaparHTML(rev ?? '');
  }

  function renderDaily() {
    if (!dailyState) return;
    const q = dailyState.questao;
    const finished = dailyState.status !== 'playing';

    // Vinheta
    document.getElementById('vinhetaText').innerHTML = revelacaoHTML(q.revelacoes[0]);

    // Pistas
    const pistasContainer = document.getElementById('pistas');
    pistasContainer.innerHTML = '';
    const numPistas = finished ? 5 : dailyState.pistasReveladas;
    for (let i = 1; i < 5; i++) {
      const pista = document.createElement('div');
      pista.className = 'pista' + (i < numPistas ? ' pista--revealed' : '');
      pista.innerHTML = `
        <span class="pista__label">Pista ${i + 1}</span>
        <p class="pista__text">${revelacaoHTML(q.revelacoes[i])}</p>
      `;
      pistasContainer.appendChild(pista);
    }

    // Barra de progresso
    const remaining = MAX_TENTATIVAS - dailyState.tentativas.length;
    renderProgressBar('progressBar', remaining);
    const attText = document.getElementById('attemptsText');
    if (!finished) {
      attText.textContent = `${remaining} tentativa${remaining !== 1 ? 's' : ''} restante${remaining !== 1 ? 's' : ''}`;
      attText.hidden = false;
    } else {
      attText.hidden = true;
    }

    // Tentativas
    renderAttempts('attemptsList', dailyState.tentativas, dailyState.resultados, q);

    // Resultado
    const resultCard = document.getElementById('resultCard');
    if (finished) {
      renderResultCard(resultCard, dailyState, getDayNumber());
      resultCard.hidden = false;
      document.getElementById('guessFormWrapper').hidden = true;
      document.getElementById('newCaseMsg').hidden = false;
    } else {
      resultCard.hidden = true;
      document.getElementById('guessFormWrapper').hidden = false;
      document.getElementById('newCaseMsg').hidden = true;
    }

    updateSidebarStats();
  }

  function submitDailyGuess(palpite) {
    if (!dailyState || dailyState.status !== 'playing') return;
    if (storage.historico.some(h => h.date === getTodayKey() && h.questionId === dailyState.questao.id)) return;

    const resultado = avaliarPalpite(palpite, dailyState.questao);
    const acertou = resultado === 'correct';
    dailyState.tentativas.push(palpite);
    dailyState.resultados.push(resultado);

    if (acertou) {
      dailyState.status = 'won';
      dailyState.pistasReveladas = 5;
    } else if (dailyState.tentativas.length >= MAX_TENTATIVAS) {
      dailyState.status = 'lost';
      dailyState.pistasReveladas = 5;
    } else {
      dailyState.pistasReveladas = Math.min(dailyState.tentativas.length + 1, 5);
    }

    if (dailyState.status !== 'playing') {
      registrarPartida(
        dailyState.questao.id,
        dailyState.status,
        dailyState.tentativas.length,
        dailyState.tentativas,
        dailyState.resultados
      );
    }

    renderDaily();

    if (dailyState.status === 'won') {
      showConfetti();
    }
  }

  // ── MODO TREINO ──

  function getEspecialidades() {
    const esp = new Set();
    CASOS_TREINO.forEach(c => esp.add(c.especialidade));
    return Array.from(esp).sort();
  }

  // Cor de cada especialidade, igual à do site. As que não estão aqui ficam cinza.
  const CORES_ESPECIALIDADE = {
    'Cardiologia': 'red', 'Toxicologia': 'red',
    'Dermatologia': 'orange', 'Reumatologia': 'orange',
    'Gastroenterologia': 'amber', 'Endocrinologia': 'yellow',
    'Pediatria': 'lime', 'Infectologia': 'emerald',
    'Oftalmologia': 'cyan', 'Pneumologia': 'sky',
    'Nefrologia': 'blue', 'Urologia': 'indigo',
    'Psiquiatria': 'violet', 'Neurologia': 'purple',
    'Ginecologia': 'fuchsia', 'Obstetrícia': 'fuchsia',
    'Oncologia': 'pink', 'Hematologia': 'rose',
    'Ortopedia': 'stone',
  };

  function initTreino() {
    const grid = document.getElementById('treinoGrid');
    grid.innerHTML = '';

    const todas = document.createElement('button');
    todas.type = 'button';
    todas.className = 'treino__card treino__card--todas';
    todas.innerHTML = `
      <span class="treino__card-name">Todas as especialidades</span>
      <span class="treino__card-count">${CASOS_TREINO.length} questões →</span>
    `;
    todas.addEventListener('click', () => startTreino(null));
    grid.appendChild(todas);

    getEspecialidades().forEach(esp => {
      const total = CASOS_TREINO.filter(c => c.especialidade === esp).length;
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'treino__card';
      const cor = CORES_ESPECIALIDADE[esp];
      if (cor) card.dataset.cor = cor;
      card.innerHTML = `
        <span class="treino__card-name">${esp}</span>
        <span class="treino__card-count">${total} ${total === 1 ? 'questão' : 'questões'}</span>
      `;
      card.addEventListener('click', () => startTreino(esp));
      grid.appendChild(card);
    });

    document.getElementById('treinoSelector').hidden = false;
    document.getElementById('treinoGame').hidden = true;
  }

  // Paginação: 10 casos por página, como no site.
  const TREINO_POR_PAGINA = 10;

  function renderTreinoNav() {
    const grid = document.getElementById('treinoNavGrid');
    const total = treinoCasos.length;
    const inicio = treinoPagina * TREINO_POR_PAGINA;
    const fim = Math.min(inicio + TREINO_POR_PAGINA, total);

    document.getElementById('treinoNavFaixa').textContent = `${inicio + 1}-${fim} de ${total}`;
    document.getElementById('treinoNavPrev').disabled = treinoPagina === 0;
    document.getElementById('treinoNavNext').disabled = fim >= total;

    const feitos = loadTreinoProgress()[treinoEspecialidade || '__todas__'] || [];
    grid.innerHTML = '';
    for (let i = inicio; i < fim; i++) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'treino__nav-num';
      if (i === treinoIndice) btn.classList.add('treino__nav-num--ativo');
      else if (feitos.includes(treinoCasos[i].id)) btn.classList.add('treino__nav-num--feito');
      btn.setAttribute('aria-label', `Caso ${i + 1}`);
      btn.textContent = i + 1;
      btn.addEventListener('click', () => abrirCasoTreino(i));
      grid.appendChild(btn);
    }
  }

  function abrirCasoTreino(indice) {
    treinoIndice = indice;
    treinoPagina = Math.floor(indice / TREINO_POR_PAGINA);
    treinoState = {
      questao: treinoCasos[indice],
      tentativas: [],
      resultados: [],
      status: 'playing',
      pistasReveladas: 1
    };
    document.getElementById('treinoContador').textContent = `Caso ${indice + 1}/${treinoCasos.length}`;
    renderTreinoNav();
    renderTreino();
  }

  function startTreino(especialidade) {
    treinoEspecialidade = especialidade;
    treinoCasos = especialidade
      ? CASOS_TREINO.filter(c => c.especialidade === especialidade)
      : [...CASOS_TREINO];

    document.getElementById('treinoSelector').hidden = true;
    document.getElementById('treinoGame').hidden = false;
    document.getElementById('treinoEspecialidade').textContent = especialidade || 'Todas as especialidades';

    // Abre no primeiro caso ainda não jogado; se acabaram, volta ao primeiro.
    const feitos = loadTreinoProgress()[especialidade || '__todas__'] || [];
    const proximo = treinoCasos.findIndex(c => !feitos.includes(c.id));
    abrirCasoTreino(proximo === -1 ? 0 : proximo);
  }

  function renderTreino() {
    if (!treinoState) return;
    const q = treinoState.questao;
    const finished = treinoState.status !== 'playing';

    document.getElementById('treinoVinhetaText').innerHTML = revelacaoHTML(q.revelacoes[0]);

    const pistasContainer = document.getElementById('treinoPistas');
    pistasContainer.innerHTML = '';
    const numPistas = finished ? 5 : treinoState.pistasReveladas;
    for (let i = 1; i < 5; i++) {
      const pista = document.createElement('div');
      pista.className = 'pista' + (i < numPistas ? ' pista--revealed' : '');
      pista.innerHTML = `
        <span class="pista__label">Pista ${i + 1}</span>
        <p class="pista__text">${revelacaoHTML(q.revelacoes[i])}</p>
      `;
      pistasContainer.appendChild(pista);
    }

    const remaining = MAX_TENTATIVAS - treinoState.tentativas.length;
    renderProgressBar('treinoProgressBar', remaining);
    const attText = document.getElementById('treinoAttemptsText');
    if (!finished) {
      attText.textContent = `${remaining} tentativa${remaining !== 1 ? 's' : ''} restante${remaining !== 1 ? 's' : ''}`;
      attText.hidden = false;
    } else {
      attText.hidden = true;
    }

    renderAttempts('treinoAttemptsList', treinoState.tentativas, treinoState.resultados, q);

    const resultCard = document.getElementById('treinoResultCard');
    if (finished) {
      renderResultCard(resultCard, treinoState, null);
      resultCard.hidden = false;
      document.getElementById('treinoGuessFormWrapper').hidden = true;
      document.getElementById('treinoNextBtn').hidden = false;
    } else {
      resultCard.hidden = true;
      document.getElementById('treinoGuessFormWrapper').hidden = false;
      document.getElementById('treinoNextBtn').hidden = true;
    }
  }

  function submitTreinoGuess(palpite) {
    if (!treinoState || treinoState.status !== 'playing') return;

    const resultado = avaliarPalpite(palpite, treinoState.questao);
    const acertou = resultado === 'correct';
    treinoState.tentativas.push(palpite);
    treinoState.resultados.push(resultado);

    if (acertou) {
      treinoState.status = 'won';
      treinoState.pistasReveladas = 5;
    } else if (treinoState.tentativas.length >= MAX_TENTATIVAS) {
      treinoState.status = 'lost';
      treinoState.pistasReveladas = 5;
    } else {
      treinoState.pistasReveladas = Math.min(treinoState.tentativas.length + 1, 5);
    }

    if (treinoState.status !== 'playing') {
      // Salvar progresso do treino
      const treinoProgress = loadTreinoProgress();
      const key = treinoEspecialidade || '__todas__';
      if (!treinoProgress[key]) treinoProgress[key] = [];
      if (!treinoProgress[key].includes(treinoState.questao.id)) {
        treinoProgress[key].push(treinoState.questao.id);
      }
      saveTreinoProgress(treinoProgress);

      storage.treinoCompletos = (storage.treinoCompletos || 0) + 1;
      saveStorage();
      renderTreinoNav(); // marca o número deste caso como concluído
    }

    renderTreino();

    if (treinoState.status === 'won') {
      showConfetti();
    }
  }

  // ── COMPONENTES COMPARTILHADOS ──

  function renderProgressBar(containerId, remaining) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    for (let i = 0; i < MAX_TENTATIVAS; i++) {
      const seg = document.createElement('div');
      seg.className = 'progress-segment' + (i < remaining ? ' progress-segment--remaining' : ' progress-segment--used');
      container.appendChild(seg);
    }
  }

  function renderAttempts(containerId, tentativas, resultados, questao) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';
    if (tentativas.length === 0) return;

    tentativas.forEach((t, i) => {
      const el = document.createElement('div');
      const resultado = resultados[i] || 'wrong';
      el.className = 'attempt attempt--' + resultado;
      el.innerHTML = `
        <span class="attempt__icon">${ICONE_RESULTADO[resultado]}</span>
        <span class="attempt__text">${t}</span>
        <span class="attempt__number">${i + 1}/${MAX_TENTATIVAS}</span>
      `;
      container.appendChild(el);
    });
  }

  function renderResultCard(container, state, numero) {
    const isWon = state.status === 'won';
    const pontos = calcularPontos(state.tentativas.length, isWon);
    const especialidade = state.questao.especialidade;

    container.className = 'result-card ' + (isWon ? 'result-card--won' : 'result-card--lost');
    container.innerHTML = `
      <div class="result__top">
        <div class="result__info">
          <p class="result__diagnosis">${state.questao.diagnostico}</p>
          <p class="result__especialidade">${especialidade}</p>
          <p class="result__message">${isWon
            ? `Acertou na ${state.tentativas.length}ª tentativa`
            : 'Não acertou desta vez'}</p>
        </div>
        <div class="result__score-box">
          <span class="result__score">${pontos > 0 ? '+' + pontos : '0'}</span>
          <span class="result__score-label">pontos</span>
        </div>
      </div>
      ${state.tentativas.length > 0 ? `
        <div class="result__attempts">
          <p class="result__attempts-header">Suas hipóteses (${state.tentativas.length}/${MAX_TENTATIVAS})</p>
          ${state.tentativas.map((t, i) => `
            <div class="attempt attempt--${state.resultados[i]}">
              <span class="attempt__icon">${ICONE_RESULTADO[state.resultados[i]]}</span>
              <span class="attempt__text">${t}</span>
            </div>
          `).join('')}
        </div>
      ` : ''}
      ${numero ? `
        <div class="result__share">
          <button type="button" class="share-btn" onclick="App.openShare()">
            📤 Compartilhar resultado
          </button>
        </div>
      ` : ''}
    `;
    container.hidden = false;
  }

  // ── ARQUIVO ──

  function renderArquivo() {
    const list = document.getElementById('arquivoList');
    const emptyMsg = document.getElementById('arquivoEmpty');
    list.innerHTML = '';

    const historico = storage.historico.slice().reverse();

    if (historico.length === 0) {
      emptyMsg.hidden = false;
      return;
    }
    emptyMsg.hidden = true;

    historico.forEach(h => {
      const caso = CASES.find(c => c.id === h.questionId);
      if (!caso) return;

      const card = document.createElement('div');
      card.className = 'arquivo__card ' + (h.status === 'won' ? 'arquivo__card--won' : 'arquivo__card--lost');
      card.innerHTML = `
        <div class="arquivo__card-top">
          <span class="arquivo__card-date">${formatDate(h.date)}</span>
          <span class="arquivo__card-status">${h.status === 'won' ? '✅' : '❌'}</span>
        </div>
        <p class="arquivo__card-diagnosis">${caso.diagnostico}</p>
        <p class="arquivo__card-esp">${caso.especialidade}</p>
        <div class="arquivo__card-bottom">
          <span>${h.tentativas}/${MAX_TENTATIVAS} tentativas</span>
          <span class="arquivo__card-pontos">${h.pontos > 0 ? '+' + h.pontos + ' pts' : '0 pts'}</span>
        </div>
      `;
      list.appendChild(card);
    });
  }

  function formatDate(dateStr) {
    const [y, m, d] = dateStr.split('-');
    return `${d}/${m}/${y}`;
  }

  // ── ESTATÍSTICAS ──

  function renderStats() {
    document.getElementById('fullStatJogados').textContent = storage.totalPlayed;
    document.getElementById('fullStatVitorias').textContent = storage.totalWon;
    const pct = storage.totalPlayed > 0 ? Math.round((storage.totalWon / storage.totalPlayed) * 100) : 0;
    document.getElementById('fullStatAcertos').textContent = pct + '%';
    document.getElementById('fullStatPontos').textContent = storage.totalPontos;
    document.getElementById('fullStatStreak').textContent = storage.streak;
    document.getElementById('fullStatMaxStreak').textContent = storage.maxStreak;
    document.getElementById('fullStatMelhorPont').textContent = storage.melhorPontuacao;
    document.getElementById('fullStatTreino').textContent = storage.treinoCompletos || 0;

    // Distribuição
    const dist = storage.distribuicao || { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, X: 0 };
    const maxDist = Math.max(...Object.values(dist), 1);
    const distContainer = document.getElementById('statsDistribution');
    distContainer.innerHTML = '';

    [1, 2, 3, 4, 5, 'X'].forEach(key => {
      const val = dist[key] || 0;
      const pct = Math.round((val / maxDist) * 100);
      const row = document.createElement('div');
      row.className = 'stats__dist-row';
      row.innerHTML = `
        <span class="stats__dist-label">${key === 'X' ? '❌' : key + 'ª'}</span>
        <div class="stats__dist-bar-wrapper">
          <div class="stats__dist-bar ${key === 'X' ? 'stats__dist-bar--fail' : ''}" style="width:${Math.max(pct, 4)}%">
            <span>${val}</span>
          </div>
        </div>
      `;
      distContainer.appendChild(row);
    });

    updateSidebarStats();
  }

  // ── AUTOCOMPLETE ──

  function setupAutocomplete(inputId, containerId, onSelect) {
    const input = document.getElementById(inputId);
    const container = document.getElementById(containerId);
    let highlightIndex = -1;

    input.addEventListener('input', () => {
      const val = input.value.trim();
      if (val.length < 2) {
        container.hidden = true;
        return;
      }

      const normalVal = normalizar(val);
      const matches = DIAGNOSTICOS.filter(d => normalizar(d).includes(normalVal)).slice(0, 8);

      if (matches.length === 0) {
        container.hidden = true;
        return;
      }

      highlightIndex = -1;
      container.innerHTML = '';
      matches.forEach((match, i) => {
        const item = document.createElement('div');
        item.className = 'autocomplete__item';
        item.textContent = match;
        item.addEventListener('click', () => {
          input.value = match;
          container.hidden = true;
          if (onSelect) onSelect(match);
        });
        item.addEventListener('mouseenter', () => {
          highlightIndex = i;
          updateHighlight(container, highlightIndex);
        });
        container.appendChild(item);
      });
      container.hidden = false;
    });

    input.addEventListener('keydown', (e) => {
      const items = container.querySelectorAll('.autocomplete__item');
      if (container.hidden || items.length === 0) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        highlightIndex = Math.min(highlightIndex + 1, items.length - 1);
        updateHighlight(container, highlightIndex);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        highlightIndex = Math.max(highlightIndex - 1, 0);
        updateHighlight(container, highlightIndex);
      } else if (e.key === 'Enter' && highlightIndex >= 0) {
        e.preventDefault();
        input.value = items[highlightIndex].textContent;
        container.hidden = true;
      }
    });

    input.addEventListener('focus', () => {
      if (input.value.trim().length >= 2) {
        input.dispatchEvent(new Event('input'));
      }
    });

    document.addEventListener('click', (e) => {
      if (!input.contains(e.target) && !container.contains(e.target)) {
        container.hidden = true;
      }
    });
  }

  function updateHighlight(container, index) {
    container.querySelectorAll('.autocomplete__item').forEach((item, i) => {
      item.classList.toggle('autocomplete__item--highlighted', i === index);
    });
  }

  // ── COMPARTILHAMENTO ──

  function generateShareText() {
    if (!dailyState) return '';
    const dayNum = getDayNumber();
    const isWon = dailyState.status === 'won';
    const pontos = calcularPontos(dailyState.tentativas.length, isWon);

    let text = `Hipótle #${dayNum}\n`;
    text += isWon
      ? `✅ Acertei na ${dailyState.tentativas.length}ª tentativa (+${pontos}pts)\n`
      : `❌ Não acertei hoje\n`;

    text += '\n';
    dailyState.resultados.forEach(r => {
      text += r === 'correct' ? '🟩' : r === 'partial' ? '🟨' : '🟥';
    });
    // Preencher os restantes com cinza
    for (let i = dailyState.resultados.length; i < MAX_TENTATIVAS; i++) {
      text += '⬜';
    }
    text += '\n\nhipotle.com.br';

    return text;
  }

  function openShare() {
    const text = generateShareText();
    const preview = document.getElementById('sharePreview');
    preview.textContent = text;
    document.getElementById('shareModal').hidden = false;
    document.getElementById('shareCopied').hidden = true;
  }

  function copyShare() {
    const text = generateShareText();
    navigator.clipboard.writeText(text).then(() => {
      document.getElementById('shareCopied').hidden = false;
      setTimeout(() => {
        document.getElementById('shareCopied').hidden = true;
      }, 2000);
    }).catch(() => {
      showToast('Não foi possível copiar');
    });
  }

  // ── TOAST ──

  function showToast(msg) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.hidden = false;
    toast.classList.add('toast--visible');
    setTimeout(() => {
      toast.classList.remove('toast--visible');
      setTimeout(() => { toast.hidden = true; }, 300);
    }, 2500);
  }

  // ── CONFETTI (simples) ──

  function showConfetti() {
    const colors = ['#22c55e', '#15803d', '#fbbf24', '#f97316', '#ef4444', '#3b82f6', '#8b5cf6'];
    const container = document.createElement('div');
    container.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9999;overflow:hidden;';
    document.body.appendChild(container);

    for (let i = 0; i < 60; i++) {
      const piece = document.createElement('div');
      const color = colors[Math.floor(Math.random() * colors.length)];
      const x = Math.random() * 100;
      const delay = Math.random() * 0.5;
      const duration = 1.5 + Math.random() * 2;
      const size = 6 + Math.random() * 8;
      const rotation = Math.random() * 360;

      piece.style.cssText = `
        position:absolute;
        left:${x}%;
        top:-20px;
        width:${size}px;
        height:${size * 0.6}px;
        background:${color};
        border-radius:2px;
        transform:rotate(${rotation}deg);
        animation:confettiFall ${duration}s ease-in ${delay}s forwards;
      `;
      container.appendChild(piece);
    }

    // Adicionar keyframe se não existe
    if (!document.getElementById('confettiStyle')) {
      const style = document.createElement('style');
      style.id = 'confettiStyle';
      style.textContent = `
        @keyframes confettiFall {
          0% { transform: translateY(0) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
      `;
      document.head.appendChild(style);
    }

    setTimeout(() => container.remove(), 4000);
  }

  // ── INICIALIZAÇÃO ──

  function init() {
    // Navegação
    document.querySelectorAll('[data-nav]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        navigateTo(el.dataset.nav);
      });
    });

    // Menu mobile
    document.getElementById('menuBtn').addEventListener('click', openMenu);
    document.getElementById('menuOverlay').addEventListener('click', closeMenu);
    document.getElementById('sidebarClose').addEventListener('click', closeMenu);

    // Autocomplete e forms do jogo diário
    setupAutocomplete('guessInput', 'autocomplete');

    document.getElementById('guessForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('guessInput');
      const val = input.value.trim();
      if (!val) return;

      // Verificar que o diagnóstico existe na lista
      const match = DIAGNOSTICOS.find(d => normalizar(d) === normalizar(val));
      if (!match) {
        showToast('Selecione um diagnóstico válido da lista');
        return;
      }

      submitDailyGuess(match);
      input.value = '';
      document.getElementById('autocomplete').hidden = true;
    });

    // Autocomplete e forms do treino
    setupAutocomplete('treinoGuessInput', 'treinoAutocomplete');

    document.getElementById('treinoGuessForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('treinoGuessInput');
      const val = input.value.trim();
      if (!val) return;

      const match = DIAGNOSTICOS.find(d => normalizar(d) === normalizar(val));
      if (!match) {
        showToast('Selecione um diagnóstico válido da lista');
        return;
      }

      submitTreinoGuess(match);
      input.value = '';
      document.getElementById('treinoAutocomplete').hidden = true;
    });

    // Botão voltar do treino
    document.getElementById('treinoBack').addEventListener('click', () => {
      treinoState = null;
      initTreino();
    });

    // Botão próximo caso do treino: avança na lista, sem sortear.
    document.getElementById('treinoNextBtn').addEventListener('click', () => {
      abrirCasoTreino((treinoIndice + 1) % treinoCasos.length);
    });

    // Setas da paginação numérica
    document.getElementById('treinoNavPrev').addEventListener('click', () => {
      if (treinoPagina > 0) { treinoPagina--; renderTreinoNav(); }
    });
    document.getElementById('treinoNavNext').addEventListener('click', () => {
      if ((treinoPagina + 1) * TREINO_POR_PAGINA < treinoCasos.length) { treinoPagina++; renderTreinoNav(); }
    });

    // Compartilhamento
    document.querySelectorAll('[data-close-share]').forEach(el => {
      el.addEventListener('click', () => {
        document.getElementById('shareModal').hidden = true;
      });
    });
    document.getElementById('shareCopyBtn').addEventListener('click', copyShare);

    // Reset stats
    document.getElementById('statsResetBtn').addEventListener('click', () => {
      if (confirm('Tem certeza que deseja resetar todas as estatísticas? Esta ação não pode ser desfeita.')) {
        storage = createFreshStorage();
        saveStorage();
        localStorage.removeItem(TREINO_KEY);
        renderStats();
        updateSidebarStats();
        showToast('Estatísticas resetadas');
      }
    });

    // Iniciar com jogo do dia
    updateSidebarStats();
    initDaily();
  }

  // Expor funções globais necessárias
  window.App = {
    openShare: openShare,
    navigateTo: navigateTo
  };

  // Iniciar quando DOM estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
